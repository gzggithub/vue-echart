(function () {
    window.configs = {
        API_PORTAL: '/apis/equip/',
        STYLE_LESS: 'common',
    };
})();
